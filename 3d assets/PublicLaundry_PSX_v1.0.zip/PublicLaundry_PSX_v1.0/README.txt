===================================================
  Public Laundry PSX Asset Pack - Version 1.0
  Created by JashiPSX
===================================================

DESCRIPTION
-----------
This is a low-poly 3D asset pack inspired by PS1-style horror and retro games.  
It includes a full set of laundromat props (with some clean and dirty variants), optimized for use in game engines such as Unity, Godot, Unreal Engine, or in 3D software like Blender.

All assets are UV-unwrapped, flat-shaded and textured for a classic PSX look.

CONTENTS
--------
Total Models: 23  
(Some models share the same mesh but use alternate textures)

Models included:
- Washing Machine (clean / dirty)
- Washing Machine Door (clean / dirty)
- Plastic Bench (clean / dirty)
- Wall Shelf
- Wall Mounted Notice Board
- Laundry Basket (empty / filled)
- Pile of Clothes
- Detergent Box (blue / green / yellow)
- Fabric Softener + Bleach
- Crumpled Shirt
- Folding Table
- Laundry Vending Machine
- Coin Changer Machine
- Ceiling Fluorescent Light Panel (dual material: base + emissive)
- AC Grill
- Water Puddle

Formats provided:
- .DAE
- .FBX
- .GLB
- .OBJ + .MTL
- .BLEND (with all models, organized by collection)

Textures:
- Located in `/textures/`
  - `/props/` — 21 unique textures used across all props
  - `/surfaces/` — floor, wall, and ceiling tileable textures
- Texture resolutions range from 64x64 to 512x512  
  - e.g. `washing-machine_clean_512.png` is shared between washer and door  
  - e.g. `fluorescent-light-panel_256.png` used with emissive material for light

USAGE INSTRUCTIONS
------------------
1. Extract the contents of the .zip file to any folder on your system.
2. Import the desired file format into your engine or 3D software.
3. Assign textures manually if not auto-linked (textures use relative paths).
4. All models are flat-shaded with PSX-style UV mapping and are fully modular.

LICENSE
-------
✔ You may use these assets in **commercial and non-commercial projects**.  
✘ You may **not redistribute**, resell, or repackage the assets, even if modified.  
✔ Credit is not required, but **appreciated** if you mention "JashiPSX" in your project.

CONTACT
-------
Feel free to follow or contact me on itch.io for feedback or future asset packs:
→ https://jashipsx.itch.io/

Thanks for using my pack!
